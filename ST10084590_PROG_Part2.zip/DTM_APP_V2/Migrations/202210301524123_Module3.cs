﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Module3 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Modules", "EntryId", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Modules", "EntryId", c => c.Int(nullable: false));
        }
    }
}
