﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Study : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Studies",
                c => new
                    {
                        StudyId = c.Int(nullable: false, identity: true),
                        NameOfModule = c.String(),
                        HoursStudied = c.Double(nullable: false),
                        DateStudied = c.String(),
                        StudyTimeId = c.String(),
                    })
                .PrimaryKey(t => t.StudyId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Studies");
        }
    }
}
