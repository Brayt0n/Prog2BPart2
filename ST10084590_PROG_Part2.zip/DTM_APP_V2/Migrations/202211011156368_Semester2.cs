﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Semester2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Semesters", "SemesterWeeks", c => c.Double(nullable: false));
            DropColumn("dbo.Semesters", "SemsterWeeks");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Semesters", "SemsterWeeks", c => c.Double(nullable: false));
            DropColumn("dbo.Semesters", "SemesterWeeks");
        }
    }
}
