﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Module31 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Modules", "SelfStudy", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Modules", "SelfStudy");
        }
    }
}
