﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Module : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Modules",
                c => new
                    {
                        ModuleCode = c.String(nullable: false, maxLength: 128),
                        ModuleName = c.String(),
                        Credits = c.Double(nullable: false),
                        Hours = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.ModuleCode);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Modules");
        }
    }
}
