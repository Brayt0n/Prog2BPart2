﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Study2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Studies", "RemainingHours", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Studies", "RemainingHours");
        }
    }
}
