﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Module2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Modules", "EntryId", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Modules", "EntryId");
        }
    }
}
