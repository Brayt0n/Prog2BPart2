﻿namespace DTM_APP_V2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Semester : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Semesters",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        SemsterWeeks = c.Double(nullable: false),
                        SemesterDate = c.String(),
                        SemesterPhase = c.Int(nullable: false),
                        SemesterEntryId = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Semesters");
        }
    }
}
