﻿using DTM_APP_V2.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace DTM_APP_V2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // the following events allow for both textBoxes to have unique watermarks that inform the user on what to enter
        #region TextBox functionality  
        // Username
        private void waterMark_GotFocus(object sender, RoutedEventArgs e)
        {
            waterMark.Visibility = Visibility.Collapsed;
            userNameTb.Visibility = Visibility.Visible;
            userNameTb.Focus();
        }

        private void userNameTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(userNameTb.Text))
            {
                userNameTb.Visibility = Visibility.Collapsed;
                waterMark.Visibility = Visibility.Visible;  
            }
        }

        // Password
        private void passwordTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(passwordTb.Password))
            {
                passwordTb.Visibility = Visibility.Collapsed;
                waterMark2.Visibility = Visibility.Visible;
            }
        }

        private void waterMark2_GotFocus(object sender, RoutedEventArgs e)
        {
            waterMark2.Visibility = Visibility.Collapsed;
            passwordTb.Visibility = Visibility.Visible;
            passwordTb.Focus();
        }
        #endregion

    

        private void exitBtn_Click(object sender, RoutedEventArgs e)
        {
            // closes the system
            Environment.Exit(0);
        }

        private void registerBtn_Click(object sender, RoutedEventArgs e)
        {
            // when the user clicks the register button
            // navigates to register page
            Register r = new Register();
            r.Show();
            this.Close();
        }

        private void loginBtn_Click(object sender, RoutedEventArgs e)
        {
            // when the user clicks the login button
            DatabaseContext db = new DatabaseContext();
            User u = new User();

            try
            {
                if (userNameTb.Text == "" || passwordTb.Password == "")
                {
                    MessageBox.Show("Please fill in all field(s).", "Blank Fields", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    // temp variables for concatenation below in the foreach loop
                    string tempUser = "";
                    string tempPassword = "";

                    // linq statement to find applicable user
                    var users = db.User.Where(x => x.Username == userNameTb.Text).ToList();
                    foreach (var item in users)
                    {
                        // temp variable stores requested data
                        tempUser += item.Username;
                    }

                    // linq statement to find applicable password
                    var passwords = db.User.Where(x => x.Password == passwordTb.Password).ToList();
                    foreach (var item in users)
                    {
                        // temp variable stores requested data
                        tempPassword += item.Password;
                    }

                    // this next linq statement will be used later on in the program
                    // -- as a means for the id to be searched for
                    var userId = from User in db.User
                                 where User.Username == userNameTb.Text
                                 select User.Id;

                    foreach (var item in userId)
                    {
                        // concatenate to a global variable
                        Course.userEntryid += item;
                    }

                    // the password must = hashed password, therefore
                    // object instantiation
                    Register r = new Register();

                    // delcaration of the final temp value
                    string tempHashedPassword = passwordTb.Password;

                    // if statement to determine of the credentials are correct
                    if (userNameTb.Text != tempUser || r.HashPassword(tempHashedPassword) != tempPassword)
                    {
                        MessageBox.Show("The username or password entered are invalid.", "Invalid Credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                        // resets id
                        Course.userEntryid = null;
                    }
                    else
                    {
                        // opens loading screen
                        // loads for 5 seconds
                        LoadingScreen ls = new LoadingScreen();
                        ls.Show();

                        // closes after 5 seconds
                        LoadTime();
                    }
                }
            }
            catch (Exception er)
            {

                MessageBox.Show("Error: " + er.Message);
            }
        }

        // timer method with variable
        DispatcherTimer timer = null;
        void LoadTime()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(3);
            timer.Tick += new EventHandler(timer_Elapsed);
            timer.Start();
        }

        void timer_Elapsed(object sender, EventArgs e)
        {
            timer.Stop();

            MainPage mp = new MainPage();
            mp.Show();
            this.Close();
        }
    }
}
