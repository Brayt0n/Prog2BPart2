﻿using DTM_APP_V2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Modules;

namespace DTM_APP_V2
{
    /// <summary>
    /// Interaction logic for MainPage.xaml
    /// </summary>
    public partial class MainPage : Window
    {
        // variable declaration
        // data for the combo box
        public string[] gridData { get; set; }

        // access variable
        public Boolean moduleAccess = false;

        // object instantiation
        DatabaseContext db = new DatabaseContext();

        public MainPage()
        {
            InitializeComponent();
            // list to store combobox options

            gridData = new string[] { "Semester", "Module", "Study"};

            DataContext = this;

            // calling of binding methods -- allows for viewing on start up
            ModuleBind();
            SemesterBind();
            StudyBind();
        }

        #region TextBox Functionality
        // Module Code
        private void codeTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(codeTb.Text))
            {
                codeTb.Visibility = Visibility.Collapsed;
                watermark1.Visibility = Visibility.Visible;
            }
        }

        private void watermark1_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark1.Visibility = Visibility.Collapsed;
            codeTb.Visibility = Visibility.Visible;
            codeTb.Focus();
        }

        // Module Name
        private void moduleTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(moduleTb.Text))
            {
                moduleTb.Visibility = Visibility.Collapsed;
                watermark2.Visibility = Visibility.Visible;
            }
        }

        private void watermark2_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark2.Visibility = Visibility.Collapsed;
            moduleTb.Visibility = Visibility.Visible;
            moduleTb.Focus();
        }

        // Module Credits
        private void creditsTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(creditsTb.Text))
            {
                creditsTb.Visibility = Visibility.Collapsed;
                watermark3.Visibility = Visibility.Visible;
            }
        }

        private void watermark3_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark3.Visibility = Visibility.Collapsed;
            creditsTb.Visibility = Visibility.Visible;
            creditsTb.Focus();
        }

        // Module Hours
        private void hoursTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(hoursTb.Text))
            {
                hoursTb.Visibility = Visibility.Collapsed;
                watermark4.Visibility = Visibility.Visible;
            }
        }

        private void watermark4_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark4.Visibility = Visibility.Collapsed;
            hoursTb.Visibility = Visibility.Visible;
            hoursTb.Focus();
        }

        // Semester weeks
        private void weeksTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(weeksTb.Text))
            {
                weeksTb.Visibility = Visibility.Collapsed;
                watermark5.Visibility = Visibility.Visible;
            }
        }

        private void watermark5_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark5.Visibility = Visibility.Collapsed;
            weeksTb.Visibility = Visibility.Visible;
            weeksTb.Focus();
        }

        // Module study -- Name
        private void moduleNameTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(moduleNameTb.Text))
            {
                moduleNameTb.Visibility = Visibility.Collapsed;
                watermark6.Visibility = Visibility.Visible;
            }
        }

        private void watermark6_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark6.Visibility = Visibility.Collapsed;
            moduleNameTb.Visibility = Visibility.Visible;
            moduleNameTb.Focus();
        }

        // Module study -- Hours
        private void moduleHoursTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(moduleHoursTb.Text))
            {
                moduleHoursTb.Visibility = Visibility.Collapsed;
                watermark7.Visibility = Visibility.Visible;
            }
        }

        private void watermark7_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark7.Visibility = Visibility.Collapsed;
            moduleHoursTb.Visibility = Visibility.Visible;
            moduleHoursTb.Focus();
        }
        #endregion

        #region Add Semester
        private void addSemesterBtn_Click(object sender, RoutedEventArgs e)
        {
            // add semster button
            try
            {
                // temp variable to store semester phase
                int phase = 0;

                // semester phase = 1
                if (rbOne.IsChecked == true)
                {
                    rbTwo.IsChecked = false;
                    phase = 1;
                }

                // semester phase = 2
                if (rbTwo.IsChecked == true)
                {
                    rbOne.IsChecked = false;
                    phase = 2;
                }

                // determines if fields are blank and will inform the user
                if (weeksTb.Text == "" || semesterDate.Text == "" || phase == 0)
                {
                    MessageBox.Show("Please fill in all fields", "Blank Fields", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    // housekeeping
                    MessageBoxResult result = MessageBox.Show("Would you like to make these entries?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        Semester SemesterObject = new Semester()
                        {
                            SemesterWeeks = Convert.ToDouble(weeksTb.Text),
                            SemesterDate = semesterDate.Text,
                            SemesterPhase = phase,
                            SemesterEntryId = Course.userEntryid
                        };

                        // saves changes
                        db.Semester.Add(SemesterObject);
                        db.SaveChanges();

                        // pair to grid -- semester
                        SemesterBind();

                        // give the temp a value
                        Course.semWeeks = Convert.ToDouble(weeksTb.Text);

                        // clears values -- housekeeping
                        weeksTb.Text = null;
                        watermark5.Visibility = Visibility.Visible;
                        semesterDate.Text = "";
                        rbOne.IsChecked = false;
                        rbTwo.IsChecked = false;

                        // set the access to true
                        moduleAccess = true;

                        // housekeeping
                        MessageBox.Show("Your values have been saved successfully", "", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        // null -- user will be able to back and change values if they wish
                    }
                }
            }
            catch (Exception er)
            {

                 MessageBox.Show("Error: " + er);
            }
        }
        #endregion

        #region Add Module
        private void addModuleBtn_Click(object sender, RoutedEventArgs e)
        {
            // add module button
            try
            {
                // will determine if the user performed semster operations first
                if (moduleAccess == false)
                {
                    MessageBox.Show("Please fill in Semester first", "", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // informs the user that they need to enter all fields
                    if (codeTb.Text == "" || moduleTb.Text == "" || creditsTb.Text == "" || hoursTb.Text == "")
                    {
                        MessageBox.Show("Please fill in all fields", "Blank Fields", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        // housekeeping
                        MessageBoxResult result = MessageBox.Show("Would you like to make these entries?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
                        if (result == MessageBoxResult.Yes)
                        {
                            // set temp variables before module insertion
                            Course.modHours = Convert.ToDouble(hoursTb.Text);
                            Course.modCredits = Convert.ToDouble(creditsTb.Text);

                            Module ModuleObject = new Module()
                            {
                                ModuleCode = codeTb.Text,
                                ModuleName = moduleTb.Text,
                                Credits = Convert.ToDouble(creditsTb.Text),
                                Hours = Convert.ToDouble(hoursTb.Text),
                                EntryId = Course.userEntryid,
                                SelfStudy = Calc()
                            };

                            // adds module object to database and saves the changes
                            db.Module.Add(ModuleObject);
                            db.SaveChanges();

                            // pair to grid -- module
                            ModuleBind();

                            // clears text box values
                            codeTb.Text = null;
                            watermark1.Visibility = Visibility.Visible;

                            moduleTb.Text = null;
                            watermark2.Visibility = Visibility.Visible;

                            creditsTb.Text = null;
                            watermark3.Visibility = Visibility.Visible;

                            hoursTb.Text = null;
                            watermark4.Visibility = Visibility.Visible;

                            // set module access to false again
                            moduleAccess = false;

                            // housekeeping
                            MessageBox.Show("Your values have been saved successfully", "", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            // null -- user will be able to back and change values if they wish
                        }
                    }
                }
            }
            catch (Exception er)
            {

                MessageBox.Show("Error: " + er);
            }
        }
        #endregion

        #region Add Study
        private void addStudyBtn_Click(object sender, RoutedEventArgs e)
        {
            // add study hours button
            // user needs to search for module

            try
            {
                // temp variable for linq
                string tempMod = "";

                // linq statement to find applicable user
                var users = db.Module.Where(x => x.ModuleName == moduleNameTb.Text).ToList();
                foreach (var item in users)
                {
                    // temp variable stores requested data
                    tempMod += item.ModuleName;
                }

                if (moduleNameTb.Text == "" || moduleHoursTb.Text == "" || DateOfStudydp.Text == "")
                {
                    MessageBox.Show("Please fill in all fields", "Blank Fields", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    // if statement to determine if the module exists
                    if (moduleNameTb.Text != tempMod)
                    {
                        MessageBox.Show("The Module you have searched for does not exist.", "Module does not exist", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        // variable to store remaining hours
                        double remainingHours = Convert.ToDouble(moduleHoursTb.Text);

                        // temp variable to store data
                        string tempHours = "";
                        // searches according to id
                        var studbind = from m in db.Module
                                       where m.EntryId == Course.userEntryid && m.ModuleName == moduleNameTb.Text
                                       select new
                                       {
                                           AfterStudy = m.SelfStudy - remainingHours
                                       };

                        foreach (var item in studbind)
                        {
                            tempHours += item.AfterStudy;
                        }

                        // housekeeping
                        MessageBoxResult result = MessageBox.Show("Would you like to make these entries?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
                        if (result == MessageBoxResult.Yes)
                        {
                            Study StudyObject = new Study()
                            {
                                NameOfModule = moduleNameTb.Text,
                                HoursStudied = Convert.ToDouble(moduleHoursTb.Text),
                                RemainingHours = tempHours,
                                DateStudied = DateOfStudydp.Text,
                                StudyTimeId = Course.userEntryid
                            };

                            // adds study object to database and saves the changes
                            db.Study.Add(StudyObject);
                            db.SaveChanges();

                            // bind to grid
                            StudyBind();

                            // housekeeping
                            MessageBox.Show("Your values have been saved successfully", "", MessageBoxButton.OK, MessageBoxImage.Information);

                            moduleNameTb.Text = null;
                            watermark6.Visibility = Visibility.Visible;

                            moduleHoursTb.Text = null;
                            watermark7.Visibility = Visibility.Visible;

                            DateOfStudydp.Text = "";
                        }
                        else
                        {
                            // null -- the user can halt the process
                        }
                    }
                }
            }
            catch (Exception er)
            {

                MessageBox.Show("Error: " + er.Message);
            }
        }
        #endregion

        private void logoutBtn_Click(object sender, RoutedEventArgs e)
        {
            // logs out the user
            try
            {
                MessageBoxResult result = MessageBox.Show("Are you sure you want to logout?", "Logout", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                   // set the id to null to reset string after very login
                   Course.userEntryid = null;

                   MainWindow mw = new MainWindow();
                    mw.Show();
                    this.Close();
                }
                else
                {
                    // null -- the current user will still be logged in the system
                }
            }
            catch (Exception er)
            {

                MessageBox.Show("Error: " + er.Message);
            }
        }

        private void exitBtn_Click(object sender, RoutedEventArgs e)
        {
            // will shutdown the system
            try
            {
                MessageBoxResult result = MessageBox.Show("Are you sure you want to Exit?", "Exit", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    Environment.Exit(0);
                }
                else
                {
                    // null -- the program will not close
                }
            }
            catch (Exception er)
            {

                MessageBox.Show("Error: " + er.Message);
            }
        }

        private void dataCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // will display datagrid according to what the user wishes to see
            if (dataCombo.SelectedItem == "Module")
            {
                DataGridStudy.Visibility = Visibility.Collapsed;
                DataGridSemester.Visibility = Visibility.Collapsed;
                DataGridModules.Visibility = Visibility.Visible;
            }

            if (dataCombo.SelectedItem == "Semester")
            {
                DataGridModules.Visibility = Visibility.Collapsed;
                DataGridStudy.Visibility = Visibility.Collapsed;
                DataGridSemester.Visibility = Visibility.Visible;
            }

            if (dataCombo.SelectedItem == "Study")
            {
                DataGridModules.Visibility = Visibility.Collapsed;
                DataGridSemester.Visibility = Visibility.Collapsed;
                DataGridStudy.Visibility = Visibility.Visible;
            }
        }

        #region LINQ Statements
        // bind to grid -- user specific
        // semester
        public void SemesterBind()
        {
            // searches according to id
            var sbind = from s in db.Semester
                        where s.SemesterEntryId == Course.userEntryid
                        select new
                        {
                            s.SemesterPhase,
                            s.SemesterWeeks,
                            s.SemesterDate
                        };

            this.DataGridSemester.ItemsSource = sbind.ToList();
        }

        // module
        public void ModuleBind()
        {
            // searches according to id
            var bind = from m in db.Module
                       where m.EntryId == Course.userEntryid 
                       select new
                       {
                           m.ModuleCode,
                           m.ModuleName,
                           m.Credits,
                           m.Hours,
                           m.SelfStudy
                       };

            this.DataGridModules.ItemsSource = bind.ToList();
        }

        // study
        public void StudyBind()
        {
            // searches according to id
            var studbind = from st in db.Study
                       where st.StudyTimeId == Course.userEntryid
                       select new
                       {
                            st.NameOfModule,
                            st.HoursStudied,
                            st.DateStudied,
                            st.RemainingHours
                       };

            this.DataGridStudy.ItemsSource = studbind.ToList();
        }
        #endregion

        private void creditsTb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // will only allow the user to enter numbers
            Regex r = new Regex("[^0-9]+");
            e.Handled = r.IsMatch(e.Text);
        }

        private void hoursTb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // will only allow the user to enter numbers
            Regex r = new Regex("[^0-9]+");
            e.Handled = r.IsMatch(e.Text);
        }

        private void weeksTb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // will only allow the user to enter numbers
            Regex r = new Regex("[^0-9]+");
            e.Handled = r.IsMatch(e.Text);
        }

        private void moduleHoursTb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // will only allow the user to enter numbers
            Regex r = new Regex("[^0-9]+");
            e.Handled = r.IsMatch(e.Text);
        }

        public double Calc()
        {
            // method will calculate self study hours

            // variable to be returned
            // use of calculation in dll file
            double selfStudyHours = Modules.Class1.calc(Course.modCredits, Course.semWeeks, Course.modHours);

            return Math.Round(selfStudyHours, 2);
        }
    }
}
