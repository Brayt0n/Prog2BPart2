﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTM_APP_V2
{
    public class Course
    {
        // class to store certain variables
        // id type variable
        public static string userEntryid;

        // temp variables
        public static double modHours;
        public static double modCredits;
        public static double semWeeks;
    }
}
