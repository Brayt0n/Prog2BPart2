﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTM_APP_V2.Model
{
    class Study
    {
        [Key]
        public int StudyId { get; set; }
        public string NameOfModule { get; set; }
        public double HoursStudied { get; set; }
        public string DateStudied { get; set; }
        public string StudyTimeId { get; set; }
        public string RemainingHours { get; set; }
    }
}
