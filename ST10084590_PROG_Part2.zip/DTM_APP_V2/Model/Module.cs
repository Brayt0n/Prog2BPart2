﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTM_APP_V2.Model
{
    class Module
    {
        [Key]
        public string ModuleCode { get; set; }
        public string ModuleName { get; set; }
        public double Credits { get; set; }
        public double Hours { get; set; }
        public double SelfStudy { get; set; }
        public string EntryId { get; set; }
    }
}
