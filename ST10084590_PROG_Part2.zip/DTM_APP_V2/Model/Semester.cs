﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTM_APP_V2
{
    class Semester
    {
        [Key]
        public int Id { get; set; }
        public double SemesterWeeks { get; set; }
        public string SemesterDate { get; set; }
        public int SemesterPhase { get; set; }
        public string SemesterEntryId { get; set; }
    }
}
