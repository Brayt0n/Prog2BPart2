﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTM_APP_V2.Model
{
    class DatabaseContext : DbContext
    {
        public DbSet<User> User { get; set; }
        public DbSet<Module> Module { get; set; }
        public DbSet<Semester> Semester { get; set; }
        public DbSet<Study> Study { get; set; }
    }
}
