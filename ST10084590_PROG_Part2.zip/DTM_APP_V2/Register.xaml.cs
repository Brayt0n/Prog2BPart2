﻿using DTM_APP_V2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTM_APP_V2
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        public Register()
        {
            InitializeComponent();
        }

        private void ListViewItem_Selected(object sender, RoutedEventArgs e)
        {
            // will navigate the user back to the login page
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        #region TextBox functionality
        // Username
        private void watermark1_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark1.Visibility = Visibility.Collapsed;
            newUserTb.Visibility = Visibility.Visible;
            newUserTb.Focus();
        }

        private void newUserTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(newUserTb.Text))
            {
                newUserTb.Visibility = Visibility.Collapsed;
                watermark1.Visibility = Visibility.Visible;
            }
        }

        // Password
        private void newPasswordTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(newPasswordTb.Password))
            {
                newPasswordTb.Visibility = Visibility.Collapsed;
                watermark2.Visibility = Visibility.Visible;
            }
        }

        private void watermark2_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark2.Visibility = Visibility.Collapsed;
            newPasswordTb.Visibility = Visibility.Visible;
            newPasswordTb.Focus();
        }

        // Confirm Password
        private void confirmPasswordTb_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(newPasswordTb.Password))
            {
                confirmPasswordTb.Visibility = Visibility.Collapsed;
                watermark3.Visibility = Visibility.Visible;
            }
        }

        private void watermark3_GotFocus(object sender, RoutedEventArgs e)
        {
            watermark3.Visibility = Visibility.Collapsed;
            confirmPasswordTb.Visibility = Visibility.Visible;
            confirmPasswordTb.Focus();
        }
        #endregion

        #region Process Register
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // when the user clicks register
            try
            {
                // create an object for student and db context
                DatabaseContext db = new DatabaseContext();
                if (newUserTb.Text == "" || newPasswordTb.Password == "" || confirmPasswordTb.Password == "")
                {
                    MessageBox.Show("Please fill in all field(s).", "Blank Fields", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (newPasswordTb.Password != confirmPasswordTb.Password)
                    {
                        MessageBox.Show("The passwords you have entered do not match", "Incorrect Password", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        MessageBoxResult result = MessageBox.Show("Would you like to proceed?", "Register", MessageBoxButton.YesNo, MessageBoxImage.Question);
                        if (result == MessageBoxResult.Yes)
                        {
                            // temp variable created to store the password before hashing
                            string tempPassword = newPasswordTb.Password;

                            User u = new User()
                            {
                                Username = newUserTb.Text,
                                // password will be saved as encrypted text in the database
                                Password = HashPassword(tempPassword)
                            };

                            // adds user to database and saves the changes
                            db.User.Add(u);
                            db.SaveChanges();

                            MessageBox.Show("You are now registered!", "", MessageBoxButton.OK, MessageBoxImage.Information);

                            // navigate back for the user to login
                            MainWindow mw = new MainWindow();
                            mw.Show();
                            this.Close();
                        }
                        else
                        {
                            // null -- user will be able to back and change values if they wish
                        }
                    }
                }
            }
            catch (Exception er)
            {
                MessageBox.Show("Error: " + er.Message);
            }
        }

        // method to hash the user password
        // accepts the temp variable above as parameters
        public string HashPassword(string encryptedPassword)
        {
            // using MDS to encrypt a string
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                //Hash data --> will return hashedPassword
                byte[] data = md5.ComputeHash(utf8.GetBytes(encryptedPassword));
                return Convert.ToBase64String(data);
            }
        }
        #endregion 
    }
}
